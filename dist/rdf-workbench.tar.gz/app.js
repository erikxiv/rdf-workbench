server = require("./server");
config = require("./config");
server.startServer(config, function(){});